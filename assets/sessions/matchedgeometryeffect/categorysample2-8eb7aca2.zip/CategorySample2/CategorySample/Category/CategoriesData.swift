//
//  CategoriesData.swift
//  CategorySample
//
//  Created by 12282035 on 4/18/24.
//

import SwiftUI

final class CategoriesData: ObservableObject {
    
    // MARK: - Value
    // MARK: Public
    @Published private(set) var itmes = [CategoryItem]()
    
    
    // MARK: - Function
    // MARK: Public
    func request() {
        Task {
            let items = [CategoryItem(code: 0, name: "채소", isSelected: true), CategoryItem(code: 1, name: "과일·견과·쌀"),
                         CategoryItem(code: 2, name: "수산·해산·건어물"), CategoryItem(code: 3, name: "정육·가공육·계란"),
                         CategoryItem(code: 4, name: "국·반찬·메인요리"), CategoryItem(code: 5, name: "면·양념·오일"),
                         CategoryItem(code: 6, name: "생수·음료"), CategoryItem(code: 7, name: "커피·차"),
                         CategoryItem(code: 8, name: "간식·과자·떡"), CategoryItem(code: 9, name: "유제품"),
                         CategoryItem(code: 10, name: "건강식품"), CategoryItem(code: 11, name: "와인·위스키"),
                         CategoryItem(code: 12, name: "전통주"), CategoryItem(code: 13, name: "주방용품"),
                         CategoryItem(code: 14, name: "생활용품·리밍"), CategoryItem(code: 15, name: "가전제품"),
                         CategoryItem(code: 16, name: "가구·인테리어"), CategoryItem(code: 17, name: "유아동"),
                         CategoryItem(code: 18, name: "스포츠·레져·캠핑"), CategoryItem(code: 19, name: "반려동물"),
                         CategoryItem(code: 20, name: "럭셔리뷰티"), CategoryItem(code: 21, name: "스킨케어·메이크업"),
                         CategoryItem(code: 22, name: "헤어·바디·구강"), CategoryItem(code: 23, name: "패션"),
                         CategoryItem(code: 24, name: "컬리상품권")]
            
            await MainActor.run { self.itmes = items }
        }
    }
    
    func handle(category: CategoryItem) {
        for i in 0..<itmes.count {
            withAnimation(.smooth) {
                itmes[i].isSelected = itmes[i] == category
            }
        }
    }
}
