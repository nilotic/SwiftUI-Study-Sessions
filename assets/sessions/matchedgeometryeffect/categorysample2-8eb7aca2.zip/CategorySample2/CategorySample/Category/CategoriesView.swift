//
//  CategoriesView.swift
//  CategorySample
//
//  Created by 12282035 on 4/18/24.
//

import SwiftUI

struct CategoriesView: View {
    
    // MARK: - Value
    // MARK: Private
    @StateObject private var data = CategoriesData()
    @Namespace private var namespace
    
    
    // MARK: - View
    // MARK: Public
    var body: some View {
        HStack(spacing: 0) {
            itemsView
            subItemsView
        }
        .navigationBarTitle("Category", displayMode: .inline)
        .onAppear {
            data.request()
        }
    }
    
    // MARK: Private
    private var itemsView: some View {
        ScrollView {
            VStack {
                ForEach(data.itmes) { category in
                    CategoryItemView(data: category) {
                        data.handle(category: category)
                    }
                    .namespace(namespace)
                }
            }
            .padding(.leading, 15)
        }
        .frame(width: 180)
    }
    
    private var subItemsView: some View {
        Color.orange
            .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}

#if DEBUG
#Preview {
    NavigationView {
        CategoriesView()
    }
}
#endif
