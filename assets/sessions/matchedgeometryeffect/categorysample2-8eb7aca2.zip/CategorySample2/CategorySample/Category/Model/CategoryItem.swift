//
//  CategoryItem.swift
//  CategorySample
//
//  Created by 12282035 on 4/18/24.
//

import SwiftUI

struct CategoryItem {
    let code: Int
    let name: String
    var isSelected = false
}

extension CategoryItem: Identifiable {
    
    var id: String {
        "\(code)\(name)\(isSelected)"
    }
}

extension CategoryItem: RawRepresentable {
    
    init?(rawValue: String) {
        let components = rawValue.components(separatedBy: "|")
        
        guard let code = Int(components.first ?? ""), let name = components.last else { return nil }
        self.code = code
        self.name = name
    }
    
    var rawValue: String {
        "\(code)|\(name)"
    }
}

extension CategoryItem: Hashable {
    
    func hash(into hasher: inout Hasher) {
        hasher.combine(rawValue)
    }
}

extension CategoryItem: Equatable {
    
    static func == (lhs: CategoryItem, rhs: CategoryItem) -> Bool {
        lhs.rawValue == rhs.rawValue
    }
}

#if DEBUG
extension CategoryItem {
    
    static var placeholder: CategoryItem {
        CategoryItem(code: 0, name: "커피 · 차")
    }
}
#endif
