//
//  CategoryItemView.swift
//  CategorySample
//
//  Created by 12282035 on 4/18/24.
//

import SwiftUI

struct CategoryItemView: View {
    
    // MARK: - Value
    // MARK: Public
    let data: CategoryItem
    var action: (() -> Void)?
    
    // MARK: Private
    @Environment(\.namespace) private var namespace
    
    
    // MARK: - View
    // MARK: Public
    var body: some View {
        ZStack {
            highlightView
            titleView
        }
        .frame(height: 56)
        .onTapGesture {
            action?()
        }
    }
    
    // MARK: Private
    private var titleView: some View {
        Text(data.name)
            .foregroundColor(.black)
            .font(.system(size: 18, weight: .semibold))
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.horizontal)
    }
    
    @ViewBuilder
    private var highlightView: some View  {
        if data.isSelected {
            Color.gray
                .matchedGeometryEffect(id: "highlihgt", in: namespace)
        }
    }
}

#if DEBUG
#Preview {
    VStack {
        CategoryItemView(data: .placeholder)
        CategoryItemView(data: CategoryItem(code: 0, name: "커피 · 차", isSelected: true))
    }
    .padding(.horizontal)
}
#endif
