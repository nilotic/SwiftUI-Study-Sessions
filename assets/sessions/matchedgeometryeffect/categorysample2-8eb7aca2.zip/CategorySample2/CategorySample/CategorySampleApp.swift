//
//  CategorySampleApp.swift
//  CategorySample
//
//  Created by 12282035 on 4/18/24.
//

import SwiftUI

@main
struct CategorySampleApp: App {
    var body: some Scene {
        WindowGroup {
            CategoriesView()
        }
    }
}
