import SwiftUI

extension View {

    func namespace(_ value: Namespace.ID) -> some View {
        environment(\.namespace, value)
    }
}

