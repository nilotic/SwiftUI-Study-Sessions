// 
//  JavaScriptMessageType.swift
//
//  Created by Den Jo on 2022/04/15.
//  Copyright © finddy Inc. All rights reserved.
//

import Foundation

enum JavaScriptMessageType {
    case openBanking
}

extension JavaScriptMessageType {
    
    var name: String {
        switch self {
        case .openBanking:      return "openBanking"
        }
    }
}
