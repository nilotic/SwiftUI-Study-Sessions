// 
//  WebViewNavigation.swift
//
//  Created by Den Jo on 2021/08/11.
//  Copyright © finddy Inc. All rights reserved.
//

import Foundation

enum WebViewNavigation {
    case forward
    case backward
    case refresh
}
