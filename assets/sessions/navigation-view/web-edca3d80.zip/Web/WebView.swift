// 
//  WebView.swift
//
//  Created by Den Jo on 2022/03/24.
//  Copyright © finddy Inc. All rights reserved.
//

import SwiftUI
import Combine

struct WebView: View {
    
    // MARK: - Value
    // MARK: Public
    var title: String = ""
    let request: URLRequest?
    var isScrollEnabled = true
    var allowsBackForwardNavigationGestures = true
    
    var statusSubject: PassthroughSubject<(Bool, URL?), Error>? = nil
    var javaScriptMessageSubject: PassthroughSubject<(String, String), Never>? = nil
    
    var isNavigatable = false
    
    // MARK: Private
    private let navigationSubject = PassthroughSubject<WebViewNavigation, Never>()

    @State private var webViewRepresentable: WebViewRepresentable? = nil
    @State private var isProgressing = false
    
    @Environment(\.dismiss) private var dismiss
    
    
    // MARK: - View
    // MARK: Public
    var body: some View {
        NavigationView {
            contentsView
                .ignoresSafeArea(.container, edges: isNavigatable ? [] : .bottom)
        }
        .navigationViewStyle(.stack)
        .task {
            webViewRepresentable = WebViewRepresentable(request: request, isScrollEnabled: isScrollEnabled, allowsBackForwardNavigationGestures: allowsBackForwardNavigationGestures,
                                                        navigationSubject: navigationSubject, statusSubject: statusSubject, javaScriptMessageSubject: javaScriptMessageSubject, isProgressing: $isProgressing)
        }
    }
    
    // MARK: Private
    private var contentsView: some View {
        ZStack {
            webView
            
            if isProgressing {
                AccounzProgressView()
            }
        }
    }
    
    @ViewBuilder
    private var webView: some View {
        if let webViewRepresentable {
            webViewRepresentable
                .navigationTitle(title)
                .navigationBarTitleDisplayMode(.inline)
                .navigationBarBackButtonHidden(true)
                .toolbar {
                    leadingBarButtonItem
                    trailingBarButtonItem
                    
                    bottomBarButtonItems
                }
                .navigationBarColor(backgroundColor: .white)
        }
    }
    
    private var leadingBarButtonItem: some ToolbarContent {
        ToolbarItem(placement: .navigationBarLeading) {
            NavigationCloseBarButton(foregroundColor: Color("violet0")) {
                dismiss()
            }
        }
    }
    
    private var trailingBarButtonItem: some ToolbarContent {
        ToolbarItem(placement: .navigationBarTrailing) {
            LogoView()
                .frame(width: 28, height: 28)
        }
    }
    
    private var bottomBarButtonItems: some ToolbarContent {
        ToolbarItemGroup(placement: .bottomBar) {
            if isNavigatable {
                HStack(spacing: 10) {
                    Button {
                        navigationSubject.send(.backward)
                        
                    } label: {
                        Image(systemName: "chevron.backward")
                    }
                    
                    
                    Button {
                        navigationSubject.send(.forward)
                        
                    } label: {
                        Image(systemName: "chevron.forward")
                    }
                    
                    Spacer()
                    
                    Button {
                        navigationSubject.send(.refresh)
                        
                    } label: {
                        Image(systemName: "arrow.clockwise")
                    }
                }
            }
        }
    }
}

extension WebView {
    
    init(title: String = "", url: URL?, isScrollEnabled: Bool = true, allowsBackForwardNavigationGestures: Bool = true,
         statusSubject: PassthroughSubject<(Bool, URL?), Error>? = nil,
         javaScriptMessageSubject: PassthroughSubject<(String, String), Never>? = nil, isNavigatable: Bool = false) {
        
        self.title = title
        self.isScrollEnabled = isScrollEnabled
        self.allowsBackForwardNavigationGestures = allowsBackForwardNavigationGestures
        
        self.statusSubject            = statusSubject
        self.javaScriptMessageSubject = javaScriptMessageSubject
      
        guard let url else {
            request = nil
            return
        }
        
        request = URLRequest(url: url)
    }
}

#if DEBUG
struct WebView_Previews: PreviewProvider {
        
    static var previews: some View {
        let view = WebView(request: URLRequest(url: URL(string: "https://www.naver.com")!), isNavigatable: true)
        
        view
            .previewDevice("iPhone 8")
            .preferredColorScheme(.light)
        
        view
            .previewDevice("iPhone 11 Pro")
            .preferredColorScheme(.light)
    }
}
#endif
