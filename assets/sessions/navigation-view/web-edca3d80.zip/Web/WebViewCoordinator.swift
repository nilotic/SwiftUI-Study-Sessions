// 
//  WebViewCoordinator.swift
//
//  Created by Den Jo on 2021/08/11.
//  Copyright © finddy Inc. All rights reserved.
//

import SwiftUI
import Combine
import WebKit

final class WebViewCoordinator: NSObject {
    
    // MARK: - Value
    // MARK: Public
    var navigationSubscriber: AnyCancellable? = nil
    
    // MARK: Private
    private let view: WebViewRepresentable
    
    
    // MARK: - Initializer
    init(view: WebViewRepresentable) {
        self.view = view
    }
    
    deinit {
        navigationSubscriber?.cancel()
    }
}

// MARK: - WKNavigation Delegate
extension WebViewCoordinator: WKNavigationDelegate {
    
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, preferences: WKWebpagePreferences, decisionHandler: @escaping (WKNavigationActionPolicy, WKWebpagePreferences) -> Void) {
        log(.info, navigationAction.request.debugDescription)

        view.isProgressing = true
        preferences.preferredContentMode = .mobile
        
        /*
        if !handle(deeplink: navigationAction.request.url?.absoluteString) {
            decisionHandler(.cancel, preferences)
            activityIndicatorView.stopAnimating()
            
        } else {
            let policy: WKNavigationActionPolicy = URL(string: "\(navigationAction.request.url?.absoluteString ?? "")") == nil ? .cancel : .allow
            decisionHandler(policy, preferences)
        }
        */
        decisionHandler(.allow, preferences)
        
        /*
        WKWebsiteDataStore.default().httpCookieStore.getAllCookies {
            log(.info, $0)
        }
        */
    }
    
    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        view.isProgressing = true
        view.statusSubject?.send((false, webView.url))
        
        navigationSubscriber = view.navigationSubject?
            .receive(on: RunLoop.main)
            .sink { navigation in
                switch navigation {
                case .backward:
                    guard webView.canGoBack else { return }
                    webView.goBack()
                    
                case .forward:
                    guard webView.canGoForward else { return }
                    webView.goForward()
                    
                case .refresh:
                    webView.reload()
                }
            }
    }
    
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        view.isProgressing = false
        
        view.statusSubject?.send((true, webView.url))
        view.statusSubject?.send(completion: .finished)
        
        /*
        webView.evaluateJavaScript("document.body.innerHTML") { value, error in
            guard let string = value as? String else {
                log(.error, error.debugDescription)
                return
            }
            
            log(.info, "\(webView.url?.absoluteString ?? "")\n\(string)")
        }
         */
    }
    
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        log(.error, error.localizedDescription)
        
        view.isProgressing = false
        view.statusSubject?.send(completion: .failure(error))
    }
    
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        log(.error, error.localizedDescription)

        view.isProgressing = false
        view.statusSubject?.send(completion: .failure(error))
    }
    
    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
        view.isProgressing = false
        view.statusSubject?.send(completion: .failure(URLError(.badServerResponse)))
    }
    
    func webView(_ webView: WKWebView, didReceiveServerRedirectForProvisionalNavigation navigation: WKNavigation!) {
        log(.info, webView.url)
    }
}

// MARK: - WKScriptMessageHandler
extension WebViewCoordinator: WKScriptMessageHandler {
    
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        switch message.name {
        case JavaScriptMessageType.openBanking.name:
            log(.info, message.body)
            
            guard let body = message.body as? String else { return }
            view.javaScriptMessageSubject?.send((message.name , body))
            
        default:
            break
        }
    }
}
