// 
//  WebViewRepresentable.swift
//
//  Created by Den Jo on 2021/08/11.
//  Copyright © finddy Inc. All rights reserved.
//

import SwiftUI
import Combine
import WebKit

struct WebViewRepresentable {
    
    // MARK: - Value
    // MARK: Public
    let request: URLRequest?
    let isScrollEnabled: Bool
    let allowsBackForwardNavigationGestures: Bool

    var navigationSubject: PassthroughSubject<WebViewNavigation, Never>?       = nil
    var statusSubject: PassthroughSubject<(Bool, URL?), Error>?                = nil
    var javaScriptMessageSubject: PassthroughSubject<(String, String), Never>? = nil
    
    @Binding var isProgressing: Bool
}

extension WebViewRepresentable: UIViewRepresentable {
    
    func makeUIView(context: Context) -> WKWebView {
        let userContentController = WKUserContentController()
        userContentController.add(context.coordinator, name: JavaScriptMessageType.openBanking.name)
        
        var configuration: WKWebViewConfiguration {
            let preferences = WKWebpagePreferences()
            preferences.allowsContentJavaScript = true
            
            let configuration = WKWebViewConfiguration()
            configuration.userContentController     = userContentController
            configuration.defaultWebpagePreferences = preferences
            
            return configuration
        }
        
        let webView = WKWebView(frame: .zero)
        //webView.navigationDelegate                  = context.coordinator
//        webView.allowsBackForwardNavigationGestures = allowsBackForwardNavigationGestures
//        webView.scrollView.isScrollEnabled          = isScrollEnabled
//        webView.backgroundColor                     = .clear
        
        if let request {
            webView.load(request)
        }
        
        return webView
    }
    
    func updateUIView(_ webView: WKWebView, context: Context) {
        
    }
    
    func makeCoordinator() -> WebViewCoordinator {
        WebViewCoordinator(view: self)
    }
}
